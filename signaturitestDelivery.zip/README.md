# Project Signature Test

Hacer el juego customizado de piedra pape y tijera. 

### Installing

```
run composer install
```

```
run index.php
```

## Authors

* **Ezequiel De Simone**

## License